import os, sqlite3, json, secrets, getpass
from pathlib import Path
from functools import wraps
from flask import Flask, request, redirect, session, jsonify, send_from_directory, render_template_string, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

ROOT=Path(__file__).resolve().parent
DB=ROOT/'store.db'
app=Flask(__name__,static_folder=None)
app.secret_key=os.environ.get('NEXRIG_SECRET') or (ROOT/'.secret').read_text().strip() if (ROOT/'.secret').exists() else secrets.token_hex(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',MAX_CONTENT_LENGTH=5*1024*1024)

def db():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c

def init():
 with db() as c:
  c.execute('CREATE TABLE IF NOT EXISTS admin (id INTEGER PRIMARY KEY, password_hash TEXT NOT NULL)')
  c.execute('CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,price REAL NOT NULL,cond TEXT NOT NULL,stock INTEGER NOT NULL,specs TEXT NOT NULL,image TEXT DEFAULT "",tested INTEGER DEFAULT 0)')
  if not c.execute('SELECT COUNT(*) FROM admin').fetchone()[0]:
   print('\nFIRST RUN: Set your private NEXRIG admin password (minimum 12 characters).')
   while True:
    p=getpass.getpass('New admin password: ')
    q=getpass.getpass('Confirm password: ')
    if len(p)>=12 and p==q: break
    print('Passwords must match and contain at least 12 characters.')
   c.execute('INSERT INTO admin(password_hash) VALUES(?)',(generate_password_hash(p),))
  if not (ROOT/'.secret').exists():
   (ROOT/'.secret').write_text(secrets.token_hex(32))

def protected(f):
 @wraps(f)
 def inner(*args,**kwargs):
  if not session.get('admin'): return redirect('/admin/login')
  return f(*args,**kwargs)
 return inner

@app.after_request
def headers(resp):
 resp.headers['X-Content-Type-Options']='nosniff'
 resp.headers['X-Frame-Options']='DENY'
 if request.path.startswith('/admin'):resp.headers['Cache-Control']='no-store'
 return resp

@app.get('/')
def home():return send_from_directory(ROOT,'index.html')
@app.get('/api/products')
def products():
 with db() as c: rows=c.execute('SELECT * FROM products ORDER BY id DESC').fetchall()
 return jsonify([dict(id=r['id'],name=r['name'],price=r['price'],cond=r['cond'],stock=r['stock'],specs=json.loads(r['specs']),image=r['image'],tested=bool(r['tested']),fps=None) for r in rows])
@app.get('/uploads/<path:name>')
def upload(name):return send_from_directory(ROOT/'uploads',name)
@app.route('/admin/login',methods=['GET','POST'])
def login():
 error=''
 if request.method=='POST':
  with db() as c: row=c.execute('SELECT password_hash FROM admin WHERE id=1').fetchone()
  if row and check_password_hash(row['password_hash'],request.form.get('password','')):
   session.clear();session['admin']=True;return redirect('/admin')
  error='Incorrect password.'
 return render_template_string(LOGIN,error=error)
@app.post('/admin/logout')
@protected
def logout():session.clear();return redirect('/admin/login')
@app.get('/admin')
@protected
def dashboard():
 with db() as c: rows=c.execute('SELECT * FROM products ORDER BY id DESC').fetchall()
 return render_template_string(ADMIN,rows=rows,total=len(rows),stock=sum(r['stock'] for r in rows),value=sum(r['stock']*r['price'] for r in rows))
@app.post('/admin/save')
@protected
def save():
 f=request.form
 try:
  name=f['name'].strip();price=float(f['price']);stock=int(f['stock']);cond=f['cond'];specs=[s.strip() for s in f.get('specs','').splitlines() if s.strip()]
  assert name and len(name)<=150 and price>=0 and stock>=0 and cond in ('New','Used','Refurbished')
 except (KeyError,ValueError,AssertionError):abort(400)
 pid=f.get('id','').strip()
 with db() as c:
  if pid:
   c.execute('UPDATE products SET name=?,price=?,stock=?,cond=?,specs=? WHERE id=?',(name,price,stock,cond,json.dumps(specs),int(pid)))
  else:
   cur=c.execute('INSERT INTO products(name,price,stock,cond,specs) VALUES(?,?,?,?,?)',(name,price,stock,cond,json.dumps(specs)))
   pid=cur.lastrowid
  file=request.files.get('image')
  if file and file.filename:
   from PIL import Image
   import io
   raw=file.read(); im=Image.open(io.BytesIO(raw));im.verify()
   im=Image.open(io.BytesIO(raw));im.thumbnail((1400,1400));im=im.convert('RGB')
   (ROOT/'uploads').mkdir(exist_ok=True)
   filename=f'{pid}-{secrets.token_hex(6)}.jpg';im.save(ROOT/'uploads'/filename,quality=88)
   c.execute('UPDATE products SET image=? WHERE id=?',('/uploads/'+filename,pid))
 return redirect('/admin')
@app.post('/admin/delete/<int:pid>')
@protected
def delete(pid):
 with db() as c:c.execute('DELETE FROM products WHERE id=?',(pid,))
 return redirect('/admin')

LOGIN="""<!doctype html><html><meta name="viewport" content="width=device-width,initial-scale=1"><title>NEXRIG Admin Login</title><style>body{background:#080a12;color:#eee;font:16px system-ui;display:grid;place-items:center;min-height:90vh}main{background:#151827;padding:35px;border:1px solid #30304a;border-radius:20px;width:min(350px,85vw)}h1{letter-spacing:3px}input,button{box-sizing:border-box;width:100%;padding:14px;margin:10px 0;border-radius:10px;border:1px solid #555;background:#0c0f1c;color:white}button{background:#7949e8;border:0;cursor:pointer}.err{color:#ff8585}</style><main><h1>NEX<span style="color:#a77cff">RIG</span></h1><p>Private administrator access</p><form method="post"><input type="password" name="password" placeholder="Admin password" autocomplete="current-password" required><button>Sign in</button></form><p class="err">{{error}}</p><a href="/" style="color:#aaa">← Back to store</a></main></html>"""
ADMIN="""<!doctype html><html><meta name="viewport" content="width=device-width,initial-scale=1"><title>NEXRIG Admin</title><style>:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#090b12;color:#f4f3ff;font:15px system-ui}header{background:#151827;border-bottom:1px solid #35344a;padding:16px 5%;display:flex;justify-content:space-between;align-items:center;gap:12px}h1{letter-spacing:2px}h1 span{color:#aa85ff}main{max-width:1150px;margin:auto;padding:25px 18px}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:15px}.card,.panel{background:#151827;border:1px solid #30354b;border-radius:16px;padding:20px}.card b{font-size:27px;color:#bb9aff}.panel{margin-top:22px}input,select,textarea{background:#0c101a;color:white;border:1px solid #3b4058;border-radius:9px;padding:11px;width:100%;font:inherit}label{display:block;margin:12px 0 6px;color:#c6c4d2}button,.button{background:#7949e8;color:white;border:0;border-radius:9px;padding:11px 16px;cursor:pointer;text-decoration:none;font:inherit}button.danger{background:#672d44}.products{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px}.product{background:#0d101a;border:1px solid #30354b;padding:16px;border-radius:12px}.product img{width:100%;height:120px;object-fit:contain}summary{cursor:pointer;color:#b99aff;font-weight:600}form.inline{display:inline}.muted{color:#9ea3b7}a{color:#b99aff}</style><header><h1>NEX<span>RIG</span> <small style="font-size:13px">ADMIN</small></h1><div><a href="/" target="_blank">View store</a> &nbsp; <form class="inline" action="/admin/logout" method="post"><button>Log out</button></form></div></header><main><h2>Store overview</h2><div class="stats"><div class="card">Products<br><b>{{total}}</b></div><div class="card">Units in stock<br><b>{{stock}}</b></div><div class="card">Inventory value<br><b>${{'%.2f'|format(value)}}</b></div></div><section class="panel"><h2>Add a product</h2><form action="/admin/save" method="post" enctype="multipart/form-data"><label>Product name</label><input name="name" required maxlength="150" placeholder="e.g. Gaming PC / RTX 2060 / Camera"><label>Price ($)</label><input name="price" type="number" min="0" step="0.01" required><label>Quantity in stock</label><input name="stock" type="number" min="0" required><label>Condition</label><select name="cond"><option>New</option><option>Used</option><option>Refurbished</option></select><label>Details / specifications (one per line)</label><textarea name="specs" rows="4"></textarea><label>Product photo (JPG, PNG or WebP, up to 5 MB)</label><input type="file" name="image" accept="image/png,image/jpeg,image/webp"><p><button>Publish product</button></p></form></section><section class="panel"><h2>Manage products</h2><div class="products">{% for p in rows %}<article class="product">{% if p['image'] %}<img src="{{p['image']}}">{% endif %}<h3>{{p['name']}}</h3><p class="muted">${{'%.2f'|format(p['price'])}} · {{p['stock']}} in stock · {{p['cond']}}</p><details><summary>Edit product</summary><form action="/admin/save" method="post" enctype="multipart/form-data"><input type="hidden" name="id" value="{{p['id']}}"><label>Name</label><input name="name" value="{{p['name']}}" required><label>Price</label><input name="price" type="number" step="0.01" min="0" value="{{p['price']}}" required><label>Stock</label><input name="stock" type="number" min="0" value="{{p['stock']}}" required><label>Condition</label><select name="cond">{% for c in ['New','Used','Refurbished'] %}<option {% if p['cond']==c %}selected{% endif %}>{{c}}</option>{% endfor %}</select><label>Details (one per line)</label><textarea name="specs" rows="4">{{p['specs']|spec_lines}}</textarea><label>Replace photo</label><input type="file" name="image" accept="image/png,image/jpeg,image/webp"><p><button>Save changes</button></p></form></details><form method="post" action="/admin/delete/{{p['id']}}" onsubmit="return confirm('Delete this product?')"><button class="danger">Delete</button></form></article>{% else %}<p class="muted">No products yet. Add your first item above.</p>{% endfor %}</div></section><p class="muted">Local starter dashboard. Orders and payments are not connected. Protect the server before public deployment.</p></main></html>"""
app.jinja_env.filters['spec_lines']=lambda s:'\n'.join(json.loads(s))
if __name__=='__main__':
 init()
 print('Open http://127.0.0.1:5000 and http://127.0.0.1:5000/admin')
 app.run(host='127.0.0.1',port=5000,debug=False)
