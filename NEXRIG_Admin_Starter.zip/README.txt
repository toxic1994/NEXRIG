NEXRIG LOCAL ADMIN STARTER

1. Install Python 3.11+ from python.org.
2. Open a terminal in this folder.
3. Run: pip install -r requirements.txt
4. Run: pip install Pillow
5. Run: python server.py
6. On first run, create your admin password in the terminal.
7. Open http://127.0.0.1:5000 for your store.
8. Open http://127.0.0.1:5000/admin to log in and manage products.

IMPORTANT: This is a local development starter, not production-ready hosting. It does not process payments or orders. The store still has placeholder seller email and policy text. Add HTTPS, persistent secret configuration, CSRF protection, rate limiting, backups and deployment hardening before putting it online. Do not open index.html directly; use the local server.
